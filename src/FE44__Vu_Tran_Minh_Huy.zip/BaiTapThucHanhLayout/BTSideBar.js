import React, { Component } from "react";

export default class BTSideBar extends Component {
  render() {
    return (
      <div>
          <h1 className="text-center">Shop Name</h1>
          <table className="table">
            <tbody>
              <tr>
                <td>Category 1</td>
              </tr>
              <tr>
                <td>Category 1</td>
              </tr>
              <tr>
                <td>Category 1</td>
              </tr>
            </tbody>
          </table>
      </div>
    );
  }
}
